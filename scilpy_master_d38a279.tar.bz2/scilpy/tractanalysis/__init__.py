
try:
    from robust_streamlines_metrics import compute_robust_tract_counts_map
except ImportError as e:
    e.args += ("Try running setup.py",)
    raise
