#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import division

import nibabel as nb
import numpy as np


def convert_mibrain_lps_to_world_ras(lps_point, ref_img_path, strict=True):
    ref_im = nb.load(ref_img_path)

    vox_to_world_ras = ref_im.affine
    vox_to_world_lps = vox_to_world_ras.copy()
    vox_to_world_lps[0:2, :] *= -1.

    world_lps_to_vox = np.linalg.inv(vox_to_world_lps)

    point_to_convert = lps_point.copy()
    if lps_point.shape[0] == 3:
        point_to_convert = np.concatenate((point_to_convert, [1.]))

    world_lps_to_world_ras = np.dot(vox_to_world_ras, world_lps_to_vox)

    if strict:
        vox_point = np.dot(world_lps_to_vox, point_to_convert)
        vox_dims = np.array(ref_im.header.get_data_shape()[:3])

        if np.any(vox_point < -0.5) or np.any(vox_point[:3] > vox_dims - 0.5):
            raise ValueError('Supplied point is not inside the image volume.')

    return np.dot(world_lps_to_world_ras, point_to_convert)
