#!/usr/bin/env python
# -*- coding: utf-8 -*-

import json
import os
import unittest

import numpy as np
import nibabel as nib

from _BaseTest import BaseTest, RedirectStdOut
from _generate_toy_data import (
    generate_fa, generate_streamlines, generate_streamlines_with_duplicates,
    slices_with_duplicate_streamlines, slices_with_streamlines)
from scripts.scil_endpoints_map import main as main_endpoints_map


class TestBundleEndpointsMap(BaseTest):
    def test(self):
        anat = generate_fa(self._tmp_dir)
        endpoints_head_map_path = os.path.join(self._tmp_dir,
                                               'endpoints_map_head.nii.gz')
        endpoints_tail_map_path = os.path.join(self._tmp_dir,
                                               'endpoints_map_tail.nii.gz')

        gt_dict = {'count': 8}
        for generate, fill_gt_data in (
                (generate_streamlines, _normal_gt_data),
                (generate_streamlines_with_duplicates, _dup_gt_data)):
            bundle_path = generate(self._tmp_dir)
            bundle_name, _ = os.path.splitext(os.path.basename(bundle_path))
            bundle_name_head = bundle_name + "_head"
            bundle_name_tail = bundle_name + "_tail"

            with RedirectStdOut() as output:
                self.call(main_endpoints_map,
                          '-f', bundle_path, anat,
                          endpoints_head_map_path, endpoints_tail_map_path)

            output_dict = json.loads('\n'.join(output))
            self.assertEqual(
                output_dict, {bundle_name_head: gt_dict,
                              bundle_name_tail: gt_dict},
                "Wrong volume per label in {}.".format(bundle_name))

            # Generate the fake ground truth
            fake_gt_head = np.zeros((5, 5, 5), dtype=np.float)
            fake_gt_tail = np.zeros((5, 5, 5), dtype=np.float)
            fill_gt_data(fake_gt_head, fake_gt_tail)

            save_to = os.path.join(self._tmp_dir, 'fake_gt_head.nii.gz')
            nib.save(nib.Nifti1Image(fake_gt_head, np.identity(4)), save_to)
            self.compare_images(endpoints_head_map_path, save_to)

            save_to = os.path.join(self._tmp_dir, 'fake_gt_tail.nii.gz')
            nib.save(nib.Nifti1Image(fake_gt_tail, np.identity(4)), save_to)
            self.compare_images(endpoints_tail_map_path, save_to)


def _normal_gt_data(fake_gt_head, fake_gt_tail):
    for sl in slices_with_streamlines:
        fake_gt_head[sl] = [1, 0, 0, 0, 0]
        fake_gt_tail[sl] = [0, 0, 0, 0, 1]


def _dup_gt_data(fake_gt_head, fake_gt_tail):
    _normal_gt_data(fake_gt_head, fake_gt_tail)
    for sl in slices_with_duplicate_streamlines:
        fake_gt_head[sl] += [1, 0, 0, 0, 0]
        fake_gt_tail[sl] += [0, 0, 0, 0, 1]


if __name__ == '__main__':
    unittest.main()
