#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import unittest

from dipy.data import get_sphere
from dipy.reconst.shm import sf_to_sh, sh_to_sf
import nibabel as nb
import numpy as np


from _BaseTest import BaseTest
from scripts.scil_compute_mean_afd_map_from_streamlines import main


class TestComputeMeanAfdMeanAlongStreamlines(BaseTest):

    def test(self):
        sp = get_sphere('repulsion724')

        # Generate a Dirac response function
        sf = np.zeros(724)
        sf[0] = 1.
        sf[362] = 1.

        # Project to SH and back to SF to approximate the signal lost because
        # of the transformation
        sh_order = 16
        sf_in_sh = sf_to_sh(sf, sp, sh_order=sh_order)
        back_in_sf = sh_to_sf(sf_in_sh, sp, sh_order=sh_order)

        # Reproject to ensure stability and get back the final SF values
        final_sh = sf_to_sh(back_in_sf, sp, sh_order=sh_order)
        final_sf = sh_to_sf(final_sh, sp, sh_order=sh_order)

        # Create fake FODF image
        nb_coeffs_sh = int(((sh_order + 1) * (sh_order + 2)) / 2.)
        fodf = np.zeros((3, 3, 3, nb_coeffs_sh))
        fodf[1, 1, 1] = final_sh
        fodf_path = os.path.join(self._tmp_dir, 'fodf.nii.gz')
        nb.save(nb.Nifti1Image(fodf, np.eye(4)), fodf_path)

        # Create fake streamline containing only one segment, aligned with the
        # SF. Since it is aligned, the mean AFD value that should be obtained
        # is exactly the value of the SF.
        strl = [np.array([[1.2, 1.0, 1.3],
                          [1.2, 1.0, 1.3] + sp.vertices[0]]) - 0.5]
        strl_path = os.path.join(self._tmp_dir, 'streamline.trk')
        tr = nb.streamlines.Tractogram(strl, affine_to_rasmm=np.eye(4))
        nb.streamlines.save(tr, strl_path)

        mean_afd_path = os.path.join(self._tmp_dir, 'afd_mean.nii.gz')
        mean_rd_path = os.path.join(self._tmp_dir, 'rd_mean.nii.gz')

        self.call(main, strl_path, fodf_path, mean_afd_path, mean_rd_path)

        results_afd_img = nb.load(mean_afd_path)
        results_afd_dat = results_afd_img.get_data()

        if not np.allclose(results_afd_dat[1, 1, 1], final_sf[0]):
            raise self.failureException(
                "The obtained AFD value is not correct. Expected {}, got {}."
                .format(final_sf[0], results_afd_dat[1, 1, 1]))

        results_rd_img = nb.load(mean_rd_path)
        results_rd_dat = results_rd_img.get_data()

        # Value is hardcoded, since to compute it we would need
        # to reimplement the computation that is supposed to be tested.
        expected_rd = 0.00897442
        if not np.allclose(results_rd_dat[1, 1, 1], expected_rd):
            raise self.failureException(
                "The obtained RD value is not correct. Expected {}, got {}."
                .format(expected_rd, results_rd_dat[1, 1, 1]))


if __name__ == '__main__':
    unittest.main()
