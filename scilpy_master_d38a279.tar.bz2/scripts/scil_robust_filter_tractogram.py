#!/usr/bin/env python
#  -*- coding: utf-8 -*-

import argparse
import itertools

from dipy.tracking.metrics import length
from dipy.tracking.streamline import set_number_of_points, transform_streamlines
from dipy.tracking._utils import _mapping_to_voxel
from dipy.tracking.vox2track import _streamlines_in_mask
import nibabel as nib
from nibabel.affines import apply_affine
import numpy as np

from scilpy.tracking.tools import subsample_streamlines
from scilpy.io.utils import (read_sphere_info_from_scene, read_info_from_mb_bdo,
                             assert_inputs_exist, assert_outputs_exists)


DESCRIPTION = """
    New version of the TrackVis style filtering.
    - Now supports compressed streamlines
    - 3 filtering modes (mask, plane and geometrical shape)
        - 3 types of shape (TrackVis sphere, Mi-Brain ellipsoid or cuboid)
    - Only support *.trk, please convert *.tck for the moment
    - Can filter using any_part, either_end,  both_ends (and --not)
    - The script is now faster (2M streamlines in a typical use-case takes 2 min.)
    WARNING : MI-Brain displays both world coordinates and voxel coordinates,
    TrackVis is in VoxMM, and this script can 'mix' both so it can be confusing

    The default filtering mode is any part, meaning that if any part of a
    streamline touches a ROI, the streamlines will be included in the segmentation.

"""


def _buildArgsParser():
    p = argparse.ArgumentParser(formatter_class=argparse.RawTextHelpFormatter,
                                description=DESCRIPTION)

    p.add_argument('in_tractogram', metavar='IN_TRACTOGRAM',
                   help='Path of the input tractogram file (.trk)')
    p.add_argument('out_tractogram', metavar='OUT_TRACTOGRAM',
                   help='Path of the output tractogram file (.trk)')

    seg_group = p.add_mutually_exclusive_group(required=True)
    seg_group.add_argument('--drawn_roi', help='Filename of a hand drawn ROI '
                                               '(.nii or .nii.gz)')
    seg_group.add_argument('--trackvis_sphere', dest='trackvis_sphere', nargs=2,
                           metavar=('SCENE_FILE', 'SPHERE_NAME'),
                           help='Need to provide the TrackVis scene file \n' +
                                'and the name of the sphere, '
                                'e.g: dissection.scene "Sphere 1"')
    seg_group.add_argument('--bdo', help='Filename of a bounding object (bdo) '
                                         'file from MI-Brain')

    seg_group.add_argument('--x_plane', type=int,
                           help='Slice number in X, in voxel space')
    seg_group.add_argument('--y_plane', type=int,
                           help='Slice number in Y, in voxel space')
    seg_group.add_argument('--z_plane', type=int,
                           help='Slice number in Z, in voxel space')

    filter_group = p.add_mutually_exclusive_group()
    filter_group.add_argument('--either_end', action='store_true',
                              help='Use either ends of a streamline as '
                                   'a criteria')
    filter_group.add_argument('--both_ends', action='store_true',
                              help='Use both ends of a streamline as '
                                   'a criteria')

    p.add_argument('--not', action='store_true', dest='is_not',
                   help='Invert the filtering')

    p.add_argument('--minL', type=float, default=0,
                   help='Minimal length of a streamline to be selected')

    p.add_argument('--maxL', type=float, default=500,
                   help='Maximal length of a streamline to be selected')

    p.add_argument('--no_empty', action='store_true',
                   help='Do not write file if there is no streamline')

    p.add_argument('-f', action='store_true', dest='overwrite',
                   help='force (overwrite output file if present)')

    return p


def verify_header_compatibility(img, tractogram):
    # Minimal verification to make sure both datasets were generated together
    if not np.allclose(img.affine, tractogram.header["voxel_to_rasmm"]):
        return False

    if not np.array_equal(img.shape[0:3], tractogram.header["dimensions"]):
        return False

    if not np.allclose(img.header.get_zooms()[0:3],
                       tractogram.header["voxel_sizes"]):
        return False

    return True


def target_line_based(streamlines, target_mask, affine=None, include=True):
    # Copy-Paste from Dipy to get indices
    target_mask = np.array(target_mask, dtype=np.uint8, copy=True)
    lin_T, offset = _mapping_to_voxel(affine, voxel_size=None)

    streamline_index = _streamlines_in_mask(
        streamlines, target_mask, lin_T, offset)

    target_indices = []
    target_streamlines = []
    for idx in np.where(streamline_index == [0, 1][include])[0]:
        target_indices.append(idx)
        target_streamlines.append(streamlines[idx])

    return target_streamlines, target_indices


def filter_grid_roi(tractogram, mask, filter_type, is_not):
    streamlines = list(tractogram.streamlines)
    transfo = tractogram.header[nib.streamlines.Field.VOXEL_TO_RASMM]

    line_based_indices = []
    if filter_type == 'any':
        _, line_based_indices = target_line_based(
            streamlines, mask, transfo)
    else:
        # For endpoint filtering, we need to keep 2 informations
        # Could be faster for either end, but the code look cleaner like this
        inv_transfo = np.linalg.inv(transfo)
        inv_transfo[0:3, 3] += 0.5
        streamline_vox = transform_streamlines(streamlines,
                                               inv_transfo)
        line_based_indices_1 = []
        line_based_indices_2 = []
        for i, line_vox in enumerate(streamline_vox):
            voxel_1 = (int(line_vox[0][0]),
                       int(line_vox[0][1]),
                       int(line_vox[0][2]))
            voxel_2 = (int(line_vox[-1][0]),
                       int(line_vox[-1][1]),
                       int(line_vox[-1][2]))
            if mask[voxel_1]:
                line_based_indices_1.append(i)
            if mask[voxel_2]:
                line_based_indices_2.append(i)

        # Both endpoints need to be in the mask (AND)
        if filter_type == 'both_ends':
            line_based_indices = np.intersect1d(line_based_indices_1,
                                                line_based_indices_2)
        # Only one endpoint need to be in the mask (OR)
        elif filter_type == 'either_end':
            line_based_indices = np.union1d(line_based_indices_1,
                                            line_based_indices_2)

    # If the --not option is used, the selection is inverted
    if is_not:
        all_indices = range(len(streamlines))
        line_based_indices = np.setdiff1d(all_indices,
                                          np.unique(line_based_indices))

    # From indices to streamlines
    final_streamlines = []
    for i in line_based_indices:
        final_streamlines.append(streamlines[int(i)])

    return final_streamlines, line_based_indices


def pre_filtering_for_geometrical_shape(tractogram, size,
                                        center, filter_type,
                                        is_in_vox):
    transfo = tractogram.header[nib.streamlines.Field.VOXEL_TO_RASMM]
    dim = tractogram.header[nib.streamlines.Field.DIMENSIONS]
    inv_transfo = np.linalg.inv(transfo)

    # Create relevant info about the ellipsoid in vox/world space
    if is_in_vox:
        center = np.asarray(apply_affine(transfo, center))
    bottom_corner = center - size
    top_corner = center + size
    x_val = [bottom_corner[0], top_corner[0]]
    y_val = [bottom_corner[1], top_corner[1]]
    z_val = [bottom_corner[2], top_corner[2]]
    corner_world = list(itertools.product(x_val, y_val, z_val))
    corner_vox = apply_affine(inv_transfo, corner_world)

    # Since the filtering using a grid is so fast, we pre-filter
    # using a BB around the ellipsoid
    min_corner = np.min(corner_vox, axis=0) - 1.0
    max_corner = np.max(corner_vox, axis=0) + 1.5
    pre_mask = np.zeros(dim)
    min_x, max_x = int(max(min_corner[0], 0)), int(min(max_corner[0], dim[0]))
    min_y, max_y = int(max(min_corner[1], 0)), int(min(max_corner[1], dim[1]))
    min_z, max_z = int(max(min_corner[2], 0)), int(min(max_corner[2], dim[2]))

    pre_mask[min_x:max_x, min_y:max_y, min_z:max_z] = 1

    return filter_grid_roi(tractogram, pre_mask, filter_type, False)


def filter_ellipsoid(tractogram, ellipsoid_radius, ellipsoid_center,
                     filter_type, is_not, is_in_vox):
    pre_filtered_streamlines, pre_filtered_indices = \
        pre_filtering_for_geometrical_shape(tractogram, ellipsoid_radius,
                                            ellipsoid_center, filter_type,
                                            is_in_vox)

    transfo = tractogram.header[nib.streamlines.Field.VOXEL_TO_RASMM]
    if is_in_vox:
        ellipsoid_center = np.asarray(apply_affine(transfo,
                                                   ellipsoid_center))
    selected_by_ellipsoid = []
    line_based_indices_1 = []
    line_based_indices_2 = []
    # This is still point based (but resampled), I had a ton of problems trying
    # to use something with intersection, but even if I could do it :
    # The result won't be identical to MI-Brain since I am not using the
    # vtkPolydata. Also it won't be identical to TrackVis either,
    # because TrackVis is point-based for Spherical ROI...
    ellipsoid_radius = np.asarray(ellipsoid_radius)
    ellipsoid_center = np.asarray(ellipsoid_center)

    res = tractogram.header[nib.streamlines.Field.VOXEL_SIZES]
    for i, line in enumerate(pre_filtered_streamlines):
        if filter_type == 'any':
            # Resample to 1/10 of the voxel size
            nb_points = max(int(length(line) / np.average(res) * 10), 2)
            line = set_number_of_points(line, nb_points)
            points_in_ellipsoid = np.sum(
                ((line - ellipsoid_center) / ellipsoid_radius) ** 2,
                axis=1)
            if len(np.argwhere(points_in_ellipsoid <= 1.0)) > 0:
                # If at least one point was in the ellipsoid, we selected
                # the streamline
                selected_by_ellipsoid.append(pre_filtered_indices[i])
        else:
            points_in_ellipsoid = np.sum(
                ((line[0] - ellipsoid_center) / ellipsoid_radius) ** 2)

            if points_in_ellipsoid <= 1.0:
                line_based_indices_1.append(pre_filtered_indices[i])

            points_in_ellipsoid = np.sum(
                ((line[-1] - ellipsoid_center) / ellipsoid_radius) ** 2)
            if points_in_ellipsoid <= 1.0:
                line_based_indices_2.append(pre_filtered_indices[i])

    # Both endpoints need to be in the mask (AND)
    if filter_type == 'both_ends':
        selected_by_ellipsoid = np.intersect1d(line_based_indices_1,
                                               line_based_indices_2)
    # Only one endpoint needs to be in the mask (OR)
    elif filter_type == 'either_end':
        selected_by_ellipsoid = np.union1d(line_based_indices_1,
                                           line_based_indices_2)
    # If the --not option is used, the selection is inverted
    if is_not:
        all_indices = range(len(tractogram.streamlines))
        selected_by_ellipsoid = np.setdiff1d(all_indices,
                                             np.unique(selected_by_ellipsoid))

    # From indices to streamlines
    final_streamlines = []
    for i in selected_by_ellipsoid:
        final_streamlines.append(tractogram.streamlines[i])

    return final_streamlines, selected_by_ellipsoid


def filter_cuboid(tractogram, cuboid_radius, cuboid_center,
                  filter_type, is_not):

    pre_filtered_streamlines, pre_filtered_indices = \
        pre_filtering_for_geometrical_shape(tractogram, cuboid_radius,
                                            cuboid_center, filter_type,
                                            False)
    selected_by_cuboid = []
    line_based_indices_1 = []
    line_based_indices_2 = []
    # Also here I am not using a mathematical intersection and
    # I am not using vtkPolyData like in MI-Brain, so not exactly the same
    cuboid_radius = np.asarray(cuboid_radius)
    cuboid_center = np.asarray(cuboid_center)
    for i, line in enumerate(pre_filtered_streamlines):
        if filter_type == 'any':
            # Resample to 1/10 of the voxel size
            res = tractogram.header[nib.streamlines.Field.VOXEL_SIZES]
            nb_points = max(int(length(line)/np.average(res) * 10), 2)
            line = set_number_of_points(line, nb_points)
            points_in_cuboid = np.abs(line - cuboid_center) / cuboid_radius

            points_in_cuboid[points_in_cuboid <= 1] = 1
            points_in_cuboid[points_in_cuboid > 1] = 0
            points_in_cuboid = np.sum(points_in_cuboid, axis=1)

            if len(np.argwhere(points_in_cuboid == 3)) > 0:
                # If at least one point was in the cuboid, we selected
                # the streamlines
                selected_by_cuboid.append(pre_filtered_indices[i])
        else:
            # Faster to do it twice than trying to do in using an array of 2
            points_in_cuboid = np.abs(line[0] - cuboid_center) / cuboid_radius
            points_in_cuboid[points_in_cuboid <= 1] = 1
            points_in_cuboid[points_in_cuboid > 1] = 0
            points_in_cuboid = np.sum(points_in_cuboid)

            if points_in_cuboid == 3:
                line_based_indices_1.append(pre_filtered_indices[i])

            points_in_cuboid = np.abs(line[-1] - cuboid_center) / cuboid_radius
            points_in_cuboid[points_in_cuboid <= 1] = 1
            points_in_cuboid[points_in_cuboid > 1] = 0
            points_in_cuboid = np.sum(points_in_cuboid)

            if points_in_cuboid == 3:
                line_based_indices_2.append(pre_filtered_indices[i])

    # Both endpoints need to be in the mask (AND)
    if filter_type == 'both_ends':
        selected_by_cuboid = np.intersect1d(line_based_indices_1,
                                            line_based_indices_2)
    # Only one endpoint need to be in the mask (OR)
    elif filter_type == 'either_end':
        selected_by_cuboid = np.union1d(line_based_indices_1,
                                        line_based_indices_2)

    # If the --not option is used, the selection is inverted
    if is_not:
        all_indices = range(len(tractogram.streamlines))
        selected_by_cuboid = np.setdiff1d(all_indices,
                                          np.unique(selected_by_cuboid))

    # From indices to streamlines
    final_streamlines = []
    for i in selected_by_cuboid:
        final_streamlines.append(tractogram.streamlines[i])

    return final_streamlines, selected_by_cuboid


def main():
    parser = _buildArgsParser()
    args = parser.parse_args()

    assert_inputs_exist(parser, [args.in_tractogram])
    if not nib.streamlines.TrkFile.is_correct_format(args.in_tractogram):
        parser.error('"{0}" invalid input tractogram'.format(args.in_tractogram))
    assert_outputs_exists(parser, args, [args.out_tractogram])

    # Convert bool variable to Dipy friendly string
    filter_type = 'any'
    if args.either_end:
        filter_type = 'either_end'
    elif args.both_ends:
        filter_type = 'both_ends'

    tractogram = nib.streamlines.load(args.in_tractogram)
    if args.drawn_roi:
        img = nib.load(args.drawn_roi)
        mask = img.get_data()
        # Simple check to verify that both datasets voxel space are the same
        if not verify_header_compatibility(img, tractogram):
            parser.error('Headers from the tractogram and the mask are not '
                         'compatible.')

        filtered_streamlines, _ = filter_grid_roi(tractogram, mask, filter_type,
                                                  args.is_not)

    # For every case, the input number must be greater or equal to 0 and below
    #  the dimension, since this is a voxel space operation

    if args.x_plane or args.y_plane or args.z_plane:
        dim = tractogram.header[nib.streamlines.Field.DIMENSIONS]

        mask = np.zeros(dim)
        if args.x_plane:
            if 0 <= args.x_plane < dim[0]:
                mask[args.x_plane, :, :] = 1
            else:
                parser.error('X slice "{0}" is not valid according to the '
                             'tractogram header.'.format(args.x_plane))
        elif args.y_plane:
            if 0 <= args.y_plane < dim[1]:
                mask[:, args.y_plane, :] = 1
            else:
                parser.error('Y slice "{0}" is not valid according to the '
                             'tractogram header.'.format(args.y_plane))
        elif args.z_plane:
            if 0 <= args.z_plane < dim[2]:
                mask[:, :, args.z_plane] = 1
            else:
                parser.error('Z slice "{0}" is not valid according to the '
                             'tractogram header.'.format(args.z_plane))

        filtered_streamlines, _ = filter_grid_roi(tractogram, mask,
                                                  filter_type,
                                                  args.is_not)
    # Both case uses the ellipsoid filtering
    # The radius array will be all equal for a sphere
    geometry = ""
    if args.bdo:
        geometry, radius, center = read_info_from_mb_bdo(args.bdo)

    if geometry == 'Ellipsoid' or args.trackvis_sphere:
        if args.bdo:
            is_in_voxel_space = False
        else:
            center, radius = read_sphere_info_from_scene(
                args.trackvis_sphere[0],
                args.trackvis_sphere[1])
            radius = np.ones((3,)) * radius
            is_in_voxel_space = True

        filtered_streamlines, _ = filter_ellipsoid(tractogram,
                                                   radius.astype(np.float32),
                                                   center.astype(np.float32),
                                                   filter_type, args.is_not,
                                                   is_in_voxel_space)

    # Cuboid uses the same reader, but calls a different function
    if geometry == 'Cuboid':
        filtered_streamlines, _ = filter_cuboid(tractogram,
                                                radius.astype(np.float32),
                                                center.astype(np.float32),
                                                filter_type, args.is_not)

    # For simplicity, the length filtering is done after (A bit slower, but
    # it is cleaner in the code, because of the --not option it would be
    # confusing to invert the condition on the fly
    filtered_streamlines = subsample_streamlines(filtered_streamlines,
                                                 min_length=args.minL,
                                                 max_length=args.maxL)

    if len(filtered_streamlines) == 0:
        if args.no_empty:
            print ("WARNING: The file {}"
                   " won't be written (0 streamline)".format(args.out_tractogram))
            return
        else:
            print("WARNING: The file {}"
                  "contains 0 streamline".format(args.out_tractogram))
    # Right now, only support *.trk file, an reference anatomy would be needed
    # for *.tck
    # Also supporting *.tck would make the script even more complex to test
    # So for now, lets relax about that
    new_tractogram = nib.streamlines.Tractogram(filtered_streamlines,
                                                affine_to_rasmm=np.eye(4))
    trkfile = nib.streamlines.TrkFile(new_tractogram,
                                      header=tractogram.header)
    nib.streamlines.save(trkfile, args.out_tractogram)


if __name__ == "__main__":
    main()
