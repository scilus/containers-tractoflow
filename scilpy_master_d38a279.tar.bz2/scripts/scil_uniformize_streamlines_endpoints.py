#!/usr/bin/env python
# -*- coding: utf-8 -*-
import argparse
import os

import nibabel as nib
import numpy as np

from scilpy.io.utils import (add_overwrite_arg, assert_outputs_exists,
                             assert_inputs_exist)


def _build_args_parser():
    p = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawTextHelpFormatter)
    p.add_argument('input',
                   help='Streamlines file.')
    p.add_argument('output',
                   help='Output path of the uniformized file.')
   
    p.add_argument('--axis', choices=['x', 'y', 'z'],
                   help='Flip the streamlines along this axis.\n'
                        'SUGGESTION: Commissural = x, '
                        'Association = y, Projection = z')
    p.add_argument('--swap', action='store_true',
                   help='Swap head <-> tail convention. '
                   'Can be useful when the reference is not in RAS.')

    add_overwrite_arg(p)

    return p


def main():
    parser = _build_args_parser()
    args = parser.parse_args()
    swap = args.swap

    if not args.axis and not args.swap:
        parser.error("Must specify at least one from --axis or --swap.")

    assert_inputs_exist(parser, [args.input])
    assert_outputs_exists(parser, args, [args.output])

    tractogram = nib.streamlines.load(args.input)
    streamlines = list(tractogram.streamlines)
    for i in range(len(streamlines)):
        if args.axis == 'x':
            if streamlines[i][0][0] > streamlines[i][-1][0]:
                streamlines[i] = streamlines[i][::-1]
        elif args.axis == 'y':
            if streamlines[i][0][1] > streamlines[i][-1][1]:
                streamlines[i] = streamlines[i][::-1]
        else:
            if streamlines[i][0][2] > streamlines[i][-1][2]:
                streamlines[i] = streamlines[i][::-1]

        if swap:
            streamlines[i] = streamlines[i][::-1]

    new_tractogram = nib.streamlines.Tractogram(streamlines,
                                                affine_to_rasmm=np.eye(4))
    format = nib.streamlines.detect_format(args.input)
    file = format(new_tractogram, header=tractogram.header)

    nib.streamlines.save(file, args.output)


if __name__ == "__main__":
    main()
